
public class TestCoverage {
    public static void main(String[] args) {
        // The following is the Contact/ContactService Test
        ContactService contactService = new ContactService();

        // Test contacts
        Contact A = new Contact("A", "Jeff", "Thornton", "987654321", "Cleveland, OH");
        Contact B = new Contact("B", "Katie", "Leffler", "010101010", "Louisville, KY");

        // Test adding contacts
        if (contactService.addContact(A)) {
            System.out.println("\nadded");
        } else {
            System.out.println("\nfailure to add contact");
        }

        if (contactService.addContact(B)) {
            System.out.println("\nadded");
        } else {
            System.out.println("\nfailure to add contact");
        }

        // Test re-adding contacts
        if (contactService.addContact(A)) {
            System.out.println("\nadded");
        } else {
            System.out.println("\nfailure to add contact");
        }

        // Print all contacts
        contactService.displayAll();

        // Test deleting a contact
        contactService.deleteContact("A");
        if (contactService.deleteContact("A")) {
            System.out.println("\ndeleted");
        } else {
            System.out.println("\nalready deleted");
        }

        // Test updating info
        contactService.updateFirstName("B", "Khira");
        contactService.updateLastName("B", "Thornton");
        contactService.updateNumber("B", "123456789");
        contactService.updateAddress("B", "Bowling Green, KY");

        // Test results
        contactService.displayAll();

        // The following is the Task/TaskService Test
        TaskService taskService = new TaskService();

        // Test tasks
        Task C = new Task("C", "Jeff", "Thornton 987654321 Cleveland OH");
        Task D = new Task("D", "Katie", "Leffler 010101010 Louisville KY");

        // Test adding tasks
        if (taskService.addTask(C)) {
            System.out.println("\nadded");
        } else {
            System.out.println("\nfailure to add task");
        }

        if (taskService.addTask(D)) {
            System.out.println("\nadded");
        } else {
            System.out.println("\nfailure to add task");
        }

        // Test re-adding tasks
        if (taskService.addTask(C)) {
            System.out.println("\nadded");
        } else {
            System.out.println("\nfailure to add task");
        }

        // Print all tasks
        taskService.displayAll();

        // Test deleting a task
        taskService.deleteTask("C");
        if (taskService.deleteTask("C")) {
            System.out.println("\ndeleted");
        } else {
            System.out.println("\nalready deleted");
        }

        // Test updating name
        taskService.updateName("D", "Maverick");

        // Test updating description
        taskService.updateDescription("D", "Jeff and Katie's son");

        // Print all tasks
        taskService.displayAll();

        // The following is the Appointment/AppointmentService Test
        AppointmentService appointmentService = new AppointmentService();

        // Test appointments
        Appointment E = new Appointment("E", "2024-01-01", "Thornton 987654321 Cleveland OH");
        Appointment F = new Appointment("F", "2026-02-02", "Leffler 010101010 Louisville KY");

        if (appointmentService.addAppointment(E)) {
            System.out.println("\nadded");
        } else {
            System.out.println("\nfailure to add appointment");
        }

        if (appointmentService.addAppointment(F)) {
            System.out.println("\nadded");
        } else {
            System.out.println("\nfailure to add appointment");
        }

        // Test re-adding appointments
        if (appointmentService.addAppointment(E)) {
            System.out.println("\nadded");
        } else {
            System.out.println("\nfailure to add appointment");
        }

        appointmentService.displayAll();

        appointmentService.deleteAppointment("E");
        if (appointmentService.deleteAppointment("E")) {
            System.out.println("\ndeleted");
        } else {
            System.out.println("\nalready deleted");
        }

        appointmentService.displayAll();
    }
}
