
import java.util.ArrayList;

public class TaskService {
    private ArrayList<Task> tasks;

    public TaskService() {
        tasks = new ArrayList<>();
    }

    public boolean addTask(Task newTask) {
        boolean isUnique = true;
        for (Task task : tasks) {
            if (task.getID().equalsIgnoreCase(newTask.getID())) {
                isUnique = false;
                break;
            }
        }

        if (isUnique) {
            tasks.add(newTask);
            return true;
        } else {
            return false;
        }
    }

    public boolean deleteTask(String ID) {
        boolean isDeleted = false;
        for (Task task : tasks) {
            if (task.getID().equalsIgnoreCase(ID)) {
                tasks.remove(task);
                isDeleted = true;
                break;
            }
        }
        return isDeleted;
    }

    public boolean updateName(String ID, String newName) {
        boolean isUpdated = false;
        for (Task task : tasks) {
            if (task.getID().equalsIgnoreCase(ID)) {
                task.setName(newName);
                isUpdated = true;
                break;
            }
        }
        return isUpdated;
    }

    public boolean updateDescription(String ID, String newDescription) {
        boolean isUpdated = false;
        for (Task task : tasks) {
            if (task.getID().equalsIgnoreCase(ID)) {
                task.setDescription(newDescription);
                isUpdated = true;
                break;
            }
        }
        return isUpdated;
    }

    public void displayAll() {
        for (Task task : tasks) {
            System.out.println(task.toString());
        }
    }
}
