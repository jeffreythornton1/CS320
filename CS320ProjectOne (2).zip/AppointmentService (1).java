
import java.util.ArrayList;

public class AppointmentService {
    private ArrayList<Appointment> appointments;

    public AppointmentService() {
        appointments = new ArrayList<>();
    }

    public boolean addAppointment(Appointment newAppointment) {
        boolean isDuplicate = false;
        for (Appointment appointment : appointments) {
            if (appointment.getID().equalsIgnoreCase(newAppointment.getID())) {
                isDuplicate = true;
                break;
            }
        }
        
        if (!isDuplicate) {
            appointments.add(newAppointment);
            return true;
        } else {
            return false;
        }
    }

    public boolean deleteAppointment(String ID) {
        boolean isDeleted = false;
        for (Appointment appointment : appointments) {
            if (appointment.getID().equalsIgnoreCase(ID)) {
                appointments.remove(appointment);
                isDeleted = true;
                break;
            }
        }
        return isDeleted;
    }

    public void displayAll() {
        for (Appointment appointment : appointments) {
            System.out.println(appointment.toString());
        }
    }
}
