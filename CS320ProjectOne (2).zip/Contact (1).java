
public class Contact {
    private String ID;
    private String firstName;
    private String lastName;
    private String number;
    private String address;

    public Contact(String ID, String firstName, String lastName, String number, String address) {
        if (ID.length() <= 10 && ID != null) {
            this.ID = ID;
        }
        setFirstName(firstName);
        setLastName(lastName);
        setNumber(number);
        setAddress(address);
    }

    protected void setFirstName(String name) {
        if (name.length() <= 10 && name != null) {
            this.firstName = name;
        }
    }

    protected void setLastName(String name) {
        if (name.length() <= 10 && name != null) {
            this.lastName = name;
        }
    }

    protected void setNumber(String number) {
        if (number.length() <= 10 && number != null) {
            this.number = number;
        }
    }

    protected void setAddress(String address) {
        if (address.length() <= 30 && address != null) {
            this.address = address;
        }
    }

    public String getID() {
        return ID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getNumber() {
        return number;
    }

    public String getAddress() {
        return address;
    }

    @Override
    public String toString() {
        return "\nContact: " + ID + "\nFirst Name: " + firstName + "\nLast Name: " + lastName +
                "\nNumber: " + number + "\nAddress: " + address;
    }
}
