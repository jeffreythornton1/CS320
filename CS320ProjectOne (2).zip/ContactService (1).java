import java.util.ArrayList;

public class ContactService {
    private ArrayList<Contact> contacts;

    public ContactService() {
        contacts = new ArrayList<>();
    }

    public boolean addContact(Contact newContact) {
        boolean exists = false;
        for (Contact person : contacts) {
            if (person.getID().equalsIgnoreCase(newContact.getID())) {
                exists = true;
                break;
            }
        }
        if (!exists) {
            contacts.add(newContact);
            return true;
        } else {
            return false;
        }
    }

    public boolean deleteContact(String ID) {
        boolean erased = false;
        for (Contact person : contacts) {
            if (person.getID().equalsIgnoreCase(ID)) {
                contacts.remove(person);
                erased = true;
                break;
            }
        }
        return erased;
    }

    public boolean updateNumber(String ID, String newNumber) {
        boolean updated = false;
        for (Contact person : contacts) {
            if (person.getID().equalsIgnoreCase(ID)) {
                person.setNumber(newNumber);
                updated = true;
                break;
            }
        }
        return updated;
    }

    public boolean updateFirstName(String ID, String newFirstName) {
        boolean updated = false;
        for (Contact person : contacts) {
            if (person.getID().equalsIgnoreCase(ID)) {
                person.setFirstName(newFirstName);
                updated = true;
                break;
            }
        }
        return updated;
    }

    public boolean updateLastName(String ID, String newLastName) {
        boolean updated = false;
        for (Contact person : contacts) {
            if (person.getID().equalsIgnoreCase(ID)) {
                person.setLastName(newLastName);
                updated = true;
                break;
            }
        }
        return updated;
    }

    public boolean updateAddress(String ID, String newAddress) {
        boolean updated = false;
        for (Contact person : contacts) {
            if (person.getID().equalsIgnoreCase(ID)) {
                person.setAddress(newAddress);
                updated = true;
                break;
            }
        }
        return updated;
    }

    public void displayAll() {
        for (Contact person : contacts) {
            System.out.println(person.toString());
        }
    }
}
